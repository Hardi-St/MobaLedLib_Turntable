#ifndef __DIAGNOSE_H__
#define __DIAGNOSE_H__

void Do_Diagnose();

#endif
