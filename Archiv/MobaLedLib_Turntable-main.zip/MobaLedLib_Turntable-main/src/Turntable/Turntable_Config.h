// Configuration for the stepper program
//
// Add all individual config lines in this file
//   Example:
//   #define PORT_CNT                       24          // Number of ports (Maximal 80)

